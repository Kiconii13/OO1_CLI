﻿#define _CRT_SECURE_NO_WARNINGS
#include "Command.h"
#include "utilities.h"
#include <chrono>
#include <iomanip>
#include <fstream>


// Provera da li ima dovoljno tokena za rad komande // nasleđena metoda za sve komande

bool Command::validTokens(const std::vector<std::string>& tokens) {
    if (tokens.size() == getNumberOfTokens()) return true;
    std::cout << "Required number of arguments (including function name) for function " + tokens[0] + " is " + std::to_string(getNumberOfTokens()) + "\n";
    return false;
}


// EchoCommand setup

EchoCommand::EchoCommand(const std::string& arg) {
    if (arg.empty()) {
        // Čitanje sa standardnog ulaza ako je argument prazan
        std::ostringstream inputBuffer;
        std::string line;
        while (true) {
            if (std::getline(std::cin, line)) {
                inputBuffer << line << '\n';
            }
            // Ako je CTRL+Z (EOF) pritisnut ili je došlo do greške pri unosu, prekida unos
            if (std::cin.eof() || std::cin.fail()) {
                std::cin.clear();
                break;
            }

        }
        argument = inputBuffer.str();
    }
    else {
        argument = readArgument(arg);
    }
}


void EchoCommand::execute() {
    std::cout << argument << std::endl;
}



// TimeCommand setup

void TimeCommand::execute() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);

    std::cout << std::put_time(std::localtime(&in_time_t), "%H:%M:%S") << std::endl;
}



// DateCommand setup

void DateCommand::execute() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);

    std::cout << std::put_time(std::localtime(&in_time_t), "%d.%m.%Y") << std::endl;
}



//TouchCommand setup

void TouchCommand::execute(const std::string& fileName) {
    // Provera da li fajl postoji
    std::ifstream inFile(fileName);
    if (inFile) {
        std::cerr << "Error: File \"" << fileName << "\" already exists." << std::endl;
        return; // Izlaz bez kreiranja fajla
    }

    // Kreiranje praznog fajla
    std::ofstream outFile(fileName);
    if (outFile) {
        std::cout << "File \"" << fileName << "\" created successfully." << std::endl;
    }
    else {
        std::cerr << "Error: Could not create file \"" << fileName << "\"." << std::endl;
    }
}



// WordCountCommand setup

WordCountCommand::WordCountCommand(const std::string& opt, const std::string& arg) : option(readOption(opt)) {
    if (arg.empty()) {
        // Čitanje sa standardnog ulaza ako je argument prazan string
        std::ostringstream inputBuffer;
        std::string line;
        while (true) {
            if (std::getline(std::cin, line)) {
                inputBuffer << line << '\n';
            }
            // Ako je CTRL+Z (EOF) pritisnut ili je došlo do greške pri unosu, prekida unos
            if (std::cin.eof() || std::cin.fail()) {
                std::cin.clear();
                break;
            }
        }
        argument = inputBuffer.str();
    }
    else {
        argument = readArgument(arg);
    }
}

void WordCountCommand::execute(){
    if (option == "-w") {
        countWords();
    }
    else if (option == "-c") {
        countChars();
    }
    else {
        std::cerr << "Unknown option: " << option << std::endl;
    }
}

void WordCountCommand::countWords() {
    std::vector<std::string> words = splitString(argument);
    std::cout << words.size() << std::endl;
}

void WordCountCommand::countChars() {
    std::cout << argument.size() << std::endl;
}